--Filename: 000002_add_primarykey_to_kriol_table.up.sql
ALTER TABLE entries
ADD id SERIAL PRIMARY KEY;