--Filename: 000002_add_primarykey_to_kriol_table.down.sql
ALTER TABLE entries
DROP id TYPE;