CREATE TABLE entries
(
    english_word text,
    kriol_word text
);