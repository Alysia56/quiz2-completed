--Filename: 000003_add_created_at_to_kriol_table.down.sql
ALTER TAABLE entries
DROP created_at TYPE;